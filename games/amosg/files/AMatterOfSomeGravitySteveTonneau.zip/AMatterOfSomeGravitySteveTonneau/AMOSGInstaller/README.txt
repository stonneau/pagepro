A matter of some gravity - 2009 Steve Tonneau
Game design, programming by Steve Tonneau.
Art by Steve Tonneau and Maeva Miralles.
Contact : stevetonneau@hotmail.fr

Installation instructions :

Note : this prototype has only been tested with windows XP and 7, 32 bits.

In the AMOSGInstaller folder, double click on setup.exe and follow the instructions.

The microsoft installer will download and install the XNA redistribuable
and microsoft .Net Framework 3.5 service pack 1 if they're not present on your computer.
This might take some time.

They can be uninstalled, as well as the game in the add / remove control panel menu.

The game will be installed in the folder :

and a shortcut will be added in the start menu.

At the end of the installation, the game will be launched immediatly.


Play instructions:

Objective :
Your goal is to reach the exit panel situated at the extreme right of the screen.
Use your environment to achieve this.
Hint : You will need to collect the lemonade bottle and the candy to use your jetpack.
Using the yellow cab is a good start to get the bottle...


To play the prototype, if you have a xbox 360 controller,
plug it to your computer before lauching the application

Otherwise, the default Keyboard controls will be used.

Controls :

			KeyBoard 		 Xbox 360 game pad

shoot			  Z			    Up LeftStick

grab / use 		  A ( hold )		    Press LeftStick ( hold )

move left		  Q 			    Left LeftStick

move right 		  D			    Right LeftStick

crouch			  S			    Down  LeftStick

jump 		  	  T			    A button

jetPack( in the air )	  T ( hold )		    A button ( hold )
	


Other controls :

Quit			  Echap			    Back button

Restart demo		  Enter			    Start button