Ce fichier zip contient le r�sultat d'un test d'ambauche
pour la soci�t� gameloft en avril 2010.

Il a �t� r�alis� durant mes soir�es sur une p�riode de 2 semaines.

Il se trouve joint � ma pr�sente candidature parce que je pense
qu'il vous permettra de juger de mes capacit�s.

Il se compose :

	+ d'un fichier texte contenant les
          r�ponses � un questionnaire

	+ du document word GD Test _ Platformer_printversion_v000.
	  Il contient les sp�cifications d'un jeu de plateforme dont les 
  	  contraintes sont �galement d�taill�es.

	+ d'un prototype du jeu de plateforme sp�cifi�, "a matter of some gravity."

	+ d'une vid�o d�montrant comment franchir le niveau

	+ d'un screenshot du niveau de d�mo.


Steve Tonneau
