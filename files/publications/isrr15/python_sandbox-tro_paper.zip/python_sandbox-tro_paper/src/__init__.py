import omniORB
omniORB.updateModule("cwc")

from main import cone_optimization
from definitions import OptimError

